import { useState, useRef, useEffect, useCallback } from 'react';

// ─── Types ───
interface HistoryItem {
  id: string;
  preview: string;
  hexCode: string;
  timestamp: number;
}

// ─── Helper: RGB to Hex ───
function rgbToHex(r: number, g: number, b: number): string {
  return ((r << 16) + (g << 8) + b).toString(16).padStart(5, '0').toUpperCase();
}

// ─── Icons ───
function UploadIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
      <polyline points="17 8 12 3 7 8" />
      <line x1="12" y1="3" x2="12" y2="15" />
    </svg>
  );
}

function CopyIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <rect x="9" y="9" width="13" height="13" rx="2" ry="2" />
      <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
    </svg>
  );
}

function CheckIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round">
      <polyline points="20 6 9 17 4 12" />
    </svg>
  );
}

function SettingsIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z" />
    </svg>
  );
}

function SunIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="5" />
      <line x1="12" y1="1" x2="12" y2="3" />
      <line x1="12" y1="21" x2="12" y2="23" />
      <line x1="4.22" y1="4.22" x2="5.64" y2="5.64" />
      <line x1="18.36" y1="18.36" x2="19.78" y2="19.78" />
      <line x1="1" y1="12" x2="3" y2="12" />
      <line x1="21" y1="12" x2="23" y2="12" />
      <line x1="4.22" y1="19.78" x2="5.64" y2="18.36" />
      <line x1="18.36" y1="5.64" x2="19.78" y2="4.22" />
    </svg>
  );
}

function MoonIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
    </svg>
  );
}

function DownloadIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
      <polyline points="7 10 12 15 17 10" />
      <line x1="12" y1="15" x2="12" y2="3" />
    </svg>
  );
}

function HeartIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
    </svg>
  );
}

function CloseIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round">
      <line x1="18" y1="6" x2="6" y2="18" />
      <line x1="6" y1="6" x2="18" y2="18" />
    </svg>
  );
}

function HistoryIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10" />
      <polyline points="12 6 12 12 16 14" />
    </svg>
  );
}

function TrashIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <polyline points="3 6 5 6 21 6" />
      <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
    </svg>
  );
}

// ─── Toast Component ───
function Toast({ message, type, onClose }: { message: string; type: 'success' | 'error' | 'info'; onClose: () => void }) {
  useEffect(() => {
    const t = setTimeout(onClose, 3000);
    return () => clearTimeout(t);
  }, [onClose]);

  const colors = {
    success: 'from-emerald-500 to-green-600',
    error: 'from-red-500 to-rose-600',
    info: 'from-blue-500 to-indigo-600',
  };

  return (
    <div className="fixed top-4 left-1/2 -translate-x-1/2 z-[9999] toast-enter">
      <div className={`bg-gradient-to-r ${colors[type]} text-white px-6 py-3 rounded-2xl shadow-2xl flex items-center gap-3 min-w-[250px]`}>
        {type === 'success' && <CheckIcon className="w-5 h-5 shrink-0" />}
        {type === 'error' && <CloseIcon className="w-5 h-5 shrink-0" />}
        {type === 'info' && (
          <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
            <circle cx="12" cy="12" r="10" /><line x1="12" y1="16" x2="12" y2="12" /><line x1="12" y1="8" x2="12.01" y2="8" />
          </svg>
        )}
        <span className="text-sm font-medium">{message}</span>
      </div>
    </div>
  );
}

// ─── Popup Component ───
function Popup({ title, message, onClose, buttonText }: { title: string; message: string; onClose: () => void; buttonText?: string }) {
  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center settings-overlay bg-black/50" onClick={onClose}>
      <div className="popup-enter bg-white dark:bg-gray-800 rounded-3xl p-6 mx-6 max-w-sm w-full shadow-2xl" onClick={e => e.stopPropagation()}>
        <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2">{title}</h3>
        <p className="text-gray-600 dark:text-gray-300 text-sm mb-5">{message}</p>
        <button
          onClick={onClose}
          className="w-full py-3 bg-gradient-to-r from-violet-500 to-purple-600 text-white rounded-xl font-semibold btn-press hover:shadow-lg transition-all"
        >
          {buttonText || 'OK'}
        </button>
      </div>
    </div>
  );
}

// ─── Main App ───
export function App() {
  const [darkMode, setDarkMode] = useState(() => {
    try {
      const saved = localStorage.getItem('theme');
      return saved ? saved === 'dark' : true;
    } catch { return true; }
  });
  const [previewSrc, setPreviewSrc] = useState<string | null>(null);
  const [hexOutput, setHexOutput] = useState<string>('');
  const [copied, setCopied] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [history, setHistory] = useState<HistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('hex-history');
      return saved ? JSON.parse(saved) : [];
    } catch { return []; }
  });
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);
  const [popup, setPopup] = useState<{ title: string; message: string; buttonText?: string } | null>(null);
  const [uploadAnim, setUploadAnim] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const adBannerRef = useRef<HTMLDivElement>(null);
  const popunderLoaded = useRef(false);

  // Theme persistence
  useEffect(() => {
    localStorage.setItem('theme', darkMode ? 'dark' : 'light');
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // History persistence
  useEffect(() => {
    try {
      localStorage.setItem('hex-history', JSON.stringify(history));
    } catch { /* storage full */ }
  }, [history]);

  // Online/offline detection
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Load ad banner when online
  useEffect(() => {
    if (isOnline && adBannerRef.current) {
      try {
        adBannerRef.current.innerHTML = '';
        const script1 = document.createElement('script');
        script1.text = `atOptions = { 'key' : 'ea38811b68984d4efeec5bb9bfb8ccb3', 'format' : 'iframe', 'height' : 50, 'width' : 320, 'params' : {} };`;
        const script2 = document.createElement('script');
        script2.src = 'https://www.highperformanceformat.com/ea38811b68984d4efeec5bb9bfb8ccb3/invoke.js';
        adBannerRef.current.appendChild(script1);
        adBannerRef.current.appendChild(script2);
      } catch { /* ad blocker */ }
    }
  }, [isOnline]);

  // Load popunder script when online
  useEffect(() => {
    if (isOnline && !popunderLoaded.current) {
      try {
        const script = document.createElement('script');
        script.src = 'https://pl28913718.effectivegatecpm.com/e8/ad/cb/e8adcbd475e67b4a08d3978a9ad084bd.js';
        document.body.appendChild(script);
        popunderLoaded.current = true;
      } catch { /* ad blocker */ }
    }
  }, [isOnline]);

  const showToast = useCallback((message: string, type: 'success' | 'error' | 'info') => {
    setToast({ message, type });
  }, []);

  const processImage = useCallback((image: HTMLImageElement) => {
    const canvas = canvasRef.current;
    if (!canvas) return '';
    const ctx = canvas.getContext('2d');
    if (!ctx) return '';

    canvas.width = 32;
    canvas.height = 32;
    ctx.drawImage(image, 0, 0, 32, 32);

    const preview = canvas.toDataURL();
    setPreviewSrc(preview);

    const imageData = ctx.getImageData(0, 0, 32, 32);
    const data = imageData.data;
    const hexArray: string[] = [];
    for (let i = 0; i < data.length; i += 4) {
      hexArray.push(rgbToHex(data[i], data[i + 1], data[i + 2]));
    }
    const output = hexArray.join(', ');
    setHexOutput(output);
    return output;
  }, []);

  const handleFileSelect = useCallback(async (file: File) => {
    if (!file.type.startsWith('image/')) {
      showToast('Please select a valid image file', 'error');
      return;
    }

    setIsProcessing(true);
    setUploadAnim(true);
    setTimeout(() => setUploadAnim(false), 600);

    try {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          try {
            const hex = processImage(img);
            // Save to history
            const canvas = canvasRef.current;
            if (canvas && hex) {
              const newItem: HistoryItem = {
                id: Date.now().toString(),
                preview: canvas.toDataURL(),
                hexCode: hex,
                timestamp: Date.now(),
              };
              setHistory(prev => [newItem, ...prev].slice(0, 50));
            }
            showToast('Image converted successfully!', 'success');
          } catch (err) {
            showToast('Error processing image: ' + (err instanceof Error ? err.message : 'Unknown error'), 'error');
          }
          setIsProcessing(false);
        };
        img.onerror = () => {
          showToast('Failed to load image', 'error');
          setIsProcessing(false);
        };
        img.src = e.target?.result as string;
      };
      reader.onerror = () => {
        showToast('Failed to read file', 'error');
        setIsProcessing(false);
      };
      reader.readAsDataURL(file);
    } catch (err) {
      showToast('Error: ' + (err instanceof Error ? err.message : 'Unknown error'), 'error');
      setIsProcessing(false);
    }
  }, [processImage, showToast]);

  const handleInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFileSelect(file);
  }, [handleFileSelect]);

  const copyHexValues = useCallback(async () => {
    if (!hexOutput) return;
    try {
      await navigator.clipboard.writeText(hexOutput);
      setCopied(true);
      showToast('Hex code copied to clipboard!', 'success');
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback
      try {
        const textarea = document.createElement('textarea');
        textarea.value = hexOutput;
        textarea.style.position = 'fixed';
        textarea.style.left = '-9999px';
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        setCopied(true);
        showToast('Hex code copied to clipboard!', 'success');
        setTimeout(() => setCopied(false), 2000);
      } catch {
        showToast('Failed to copy hex values', 'error');
      }
    }
  }, [hexOutput, showToast]);

  const loadFromHistory = useCallback((item: HistoryItem) => {
    setPreviewSrc(item.preview);
    setHexOutput(item.hexCode);
    setShowHistory(false);
    showToast('Loaded from history', 'info');
  }, [showToast]);

  const deleteHistoryItem = useCallback((id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setHistory(prev => prev.filter(item => item.id !== id));
    showToast('Removed from history', 'info');
  }, [showToast]);

  const clearHistory = useCallback(() => {
    setHistory([]);
    showToast('History cleared', 'info');
  }, [showToast]);

  const handleModPackDownload = useCallback(() => {
    window.open('https://dl.springsfern.in/dl/AAAAAYAhAzxVqDFOAAAbuQ/JzRuNfzziHIOLxbaR2urbmZR9wva1e3ctIGmlqPLM_E', '_blank');
    setPopup({
      title: '📦 Mod Pack Downloading',
      message: 'Mod pack download started completely! Check your device downloads folder.',
      buttonText: 'Got it!',
    });
  }, []);

  const bg = darkMode
    ? 'bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950'
    : 'bg-gradient-to-br from-slate-50 via-white to-violet-50';
  const textPrimary = darkMode ? 'text-white' : 'text-gray-900';
  const textSecondary = darkMode ? 'text-gray-400' : 'text-gray-500';
  const cardBg = darkMode ? 'bg-gray-800/60 border-gray-700/50' : 'bg-white/80 border-gray-200';

  return (
    <div className={`min-h-screen ${bg} transition-colors duration-500 overflow-x-hidden`}>
      {/* Hidden elements */}
      <canvas ref={canvasRef} className="hidden" />
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleInputChange}
        className="hidden"
      />

      {/* Toast */}
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}

      {/* Popup */}
      {popup && <Popup title={popup.title} message={popup.message} onClose={() => setPopup(null)} buttonText={popup.buttonText} />}

      {/* Ad Banner Area - Top */}
      <div className="w-full flex justify-center" style={{ minHeight: isOnline ? '50px' : '0px' }}>
        {isOnline && (
          <div ref={adBannerRef} className="flex justify-center items-center" style={{ width: 320, height: 50 }} />
        )}
      </div>

      {/* Header */}
      <header className="flex items-center justify-between px-4 py-3 animate-fade-in">
        <h1 className={`text-xl font-bold ${textPrimary} tracking-tight`}>
          <span className="bg-gradient-to-r from-violet-500 via-purple-500 to-pink-500 bg-clip-text text-transparent">
            Custom Paintings
          </span>
          <span className="ml-1">🎨</span>
        </h1>
        <div className="flex gap-2">
          <button
            onClick={() => setShowHistory(true)}
            className={`p-2.5 rounded-xl ${darkMode ? 'bg-gray-800 hover:bg-gray-700 text-gray-300' : 'bg-gray-100 hover:bg-gray-200 text-gray-600'} transition-all btn-press`}
            title="History"
          >
            <HistoryIcon className="w-5 h-5" />
          </button>
          <button
            onClick={() => setShowSettings(true)}
            className={`p-2.5 rounded-xl ${darkMode ? 'bg-gray-800 hover:bg-gray-700 text-gray-300' : 'bg-gray-100 hover:bg-gray-200 text-gray-600'} transition-all btn-press`}
            title="Settings"
          >
            <SettingsIcon className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="px-4 pb-8 max-w-lg mx-auto">
        {/* Upload Button */}
        <div className="mt-4 animate-slide-up" style={{ animationDelay: '0.1s' }}>
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={isProcessing}
            className={`w-full py-8 rounded-3xl border-2 border-dashed transition-all duration-300 btn-press ripple-container
              ${darkMode
                ? 'border-violet-500/40 bg-violet-500/5 hover:bg-violet-500/10 hover:border-violet-400'
                : 'border-violet-300 bg-violet-50 hover:bg-violet-100 hover:border-violet-400'
              }
              ${uploadAnim ? 'animate-bounce-in' : ''}
              ${isProcessing ? 'opacity-60 cursor-wait' : 'cursor-pointer'}
            `}
          >
            <div className="flex flex-col items-center gap-3">
              <div className={`p-4 rounded-2xl ${darkMode ? 'bg-violet-500/20' : 'bg-violet-200/60'} animate-float`}>
                <UploadIcon className={`w-10 h-10 ${darkMode ? 'text-violet-400' : 'text-violet-600'}`} />
              </div>
              <div>
                <p className={`text-lg font-bold ${darkMode ? 'text-violet-300' : 'text-violet-700'}`}>
                  {isProcessing ? 'Processing...' : 'Upload Image'}
                </p>
                <p className={`text-sm mt-1 ${textSecondary}`}>
                  Tap to select an image file
                </p>
              </div>
            </div>
          </button>
        </div>

        {/* Image Preview */}
        {previewSrc && (
          <div className="mt-6 flex flex-col items-center animate-bounce-in">
            <p className={`text-sm font-semibold mb-3 ${textSecondary} uppercase tracking-wider`}>Preview</p>
            <div className="image-frame">
              <div className={`rounded-xl overflow-hidden ${darkMode ? 'bg-gray-900' : 'bg-gray-100'}`}>
                <img
                  src={previewSrc}
                  alt="Preview"
                  className="w-44 h-44 object-contain"
                  style={{ imageRendering: 'pixelated' }}
                />
              </div>
            </div>
          </div>
        )}

        {/* Hex Output */}
        {hexOutput && (
          <div className="mt-6 animate-slide-up">
            <div className={`relative rounded-2xl border ${cardBg} backdrop-blur-sm overflow-hidden`}>
              {/* Header bar */}
              <div className={`flex items-center justify-between px-4 py-3 border-b ${darkMode ? 'border-gray-700/50' : 'border-gray-200'}`}>
                <span className={`text-xs font-semibold uppercase tracking-wider ${textSecondary}`}>Hex Code</span>
                <button
                  onClick={copyHexValues}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all duration-300 btn-press
                    ${copied
                      ? 'bg-gradient-to-r from-emerald-500 to-green-500 text-white shadow-lg shadow-emerald-500/30'
                      : `bg-gradient-to-r from-violet-500 to-purple-600 text-white shadow-lg shadow-violet-500/30 hover:shadow-violet-500/50 ${!copied ? 'animate-shimmer' : ''}`
                    }
                  `}
                >
                  {copied ? (
                    <>
                      <CheckIcon className="w-4 h-4" />
                      <span>Copied!</span>
                    </>
                  ) : (
                    <>
                      <CopyIcon className="w-4 h-4" />
                      <span>Copy</span>
                    </>
                  )}
                </button>
              </div>
              {/* Code area */}
              <div className="p-4 max-h-48 overflow-y-auto custom-scroll">
                <pre className={`text-xs leading-relaxed break-all whitespace-pre-wrap font-mono hex-output ${darkMode ? 'text-green-400' : 'text-gray-700'}`}>
                  {hexOutput}
                </pre>
              </div>
            </div>
          </div>
        )}

        {/* Empty state when no image */}
        {!previewSrc && !hexOutput && (
          <div className="mt-12 flex flex-col items-center animate-fade-in" style={{ animationDelay: '0.3s' }}>
            <div className={`w-20 h-20 rounded-3xl flex items-center justify-center mb-4 ${darkMode ? 'bg-gray-800/50' : 'bg-gray-100'}`}>
              <span className="text-4xl">🖼️</span>
            </div>
            <p className={`text-sm ${textSecondary} text-center`}>
              Upload an image to convert it<br />into hex color codes
            </p>
          </div>
        )}
      </main>

      {/* Settings Panel */}
      {showSettings && (
        <div className="fixed inset-0 z-[999] settings-overlay bg-black/50" onClick={() => setShowSettings(false)}>
          <div
            className={`fixed bottom-0 left-0 right-0 ${darkMode ? 'bg-gray-900' : 'bg-white'} rounded-t-3xl animate-slide-up max-h-[85vh] overflow-y-auto custom-scroll`}
            onClick={e => e.stopPropagation()}
          >
            {/* Handle bar */}
            <div className="flex justify-center pt-3 pb-1">
              <div className={`w-10 h-1 rounded-full ${darkMode ? 'bg-gray-700' : 'bg-gray-300'}`} />
            </div>
            
            {/* Settings Header */}
            <div className="flex items-center justify-between px-5 py-3">
              <h2 className={`text-xl font-bold ${textPrimary}`}>⚙️ Settings</h2>
              <button
                onClick={() => setShowSettings(false)}
                className={`p-2 rounded-xl ${darkMode ? 'bg-gray-800 hover:bg-gray-700' : 'bg-gray-100 hover:bg-gray-200'} transition-all btn-press`}
              >
                <CloseIcon className={`w-5 h-5 ${darkMode ? 'text-gray-400' : 'text-gray-500'}`} />
              </button>
            </div>

            <div className="px-5 pb-8 space-y-3">
              {/* Theme Toggle */}
              <button
                onClick={() => setDarkMode(!darkMode)}
                className={`w-full flex items-center justify-between p-4 rounded-2xl border transition-all btn-press
                  ${darkMode ? 'bg-gray-800/60 border-gray-700/50 hover:bg-gray-800' : 'bg-gray-50 border-gray-200 hover:bg-gray-100'}
                `}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2.5 rounded-xl ${darkMode ? 'bg-yellow-500/20' : 'bg-indigo-500/10'}`}>
                    {darkMode ? <SunIcon className="w-5 h-5 text-yellow-400" /> : <MoonIcon className="w-5 h-5 text-indigo-500" />}
                  </div>
                  <div className="text-left">
                    <p className={`font-semibold ${textPrimary}`}>{darkMode ? 'Light Mode' : 'Dark Mode'}</p>
                    <p className={`text-xs ${textSecondary}`}>Switch to {darkMode ? 'light' : 'dark'} theme</p>
                  </div>
                </div>
                <div className={`w-12 h-7 rounded-full transition-colors duration-300 flex items-center ${darkMode ? 'bg-violet-500 justify-end' : 'bg-gray-300 justify-start'}`}>
                  <div className="w-5 h-5 bg-white rounded-full shadow-md mx-1 transition-all" />
                </div>
              </button>

              {/* Mod Pack Download */}
              <button
                onClick={handleModPackDownload}
                className={`w-full flex items-center gap-3 p-4 rounded-2xl border transition-all btn-press
                  ${darkMode ? 'bg-gray-800/60 border-gray-700/50 hover:bg-gray-800' : 'bg-gray-50 border-gray-200 hover:bg-gray-100'}
                `}
              >
                <div className="p-2.5 rounded-xl bg-emerald-500/20">
                  <DownloadIcon className="w-5 h-5 text-emerald-400" />
                </div>
                <div className="text-left">
                  <p className={`font-semibold ${textPrimary}`}>Mod Pack</p>
                  <p className={`text-xs ${textSecondary}`}>Download the mod pack to your device</p>
                </div>
              </button>

              {/* Help the Creator */}
              <button
                onClick={() => window.open('https://youtube.com/@imgmine?si=wBsvUitLV10EStTg', '_blank')}
                className={`w-full flex items-center gap-3 p-4 rounded-2xl border transition-all btn-press
                  ${darkMode ? 'bg-gray-800/60 border-gray-700/50 hover:bg-gray-800' : 'bg-gray-50 border-gray-200 hover:bg-gray-100'}
                `}
              >
                <div className="p-2.5 rounded-xl bg-red-500/20">
                  <HeartIcon className="w-5 h-5 text-red-400" />
                </div>
                <div className="text-left">
                  <p className={`font-semibold ${textPrimary}`}>Help the Creator</p>
                  <p className={`text-xs ${textSecondary}`}>Support us on YouTube</p>
                </div>
              </button>

              {/* Made by */}
              <div className="pt-6 text-center">
                <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full ${darkMode ? 'bg-gray-800/40' : 'bg-gray-100'}`}>
                  <span className="text-lg">✨</span>
                  <span className={`text-sm font-semibold bg-gradient-to-r from-violet-400 via-pink-400 to-orange-400 bg-clip-text text-transparent`}>
                    Made by IMG Mine YT
                  </span>
                  <span className="text-lg">✨</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* History Panel */}
      {showHistory && (
        <div className="fixed inset-0 z-[999] settings-overlay bg-black/50" onClick={() => setShowHistory(false)}>
          <div
            className={`fixed bottom-0 left-0 right-0 ${darkMode ? 'bg-gray-900' : 'bg-white'} rounded-t-3xl animate-slide-up max-h-[85vh] flex flex-col`}
            onClick={e => e.stopPropagation()}
          >
            {/* Handle bar */}
            <div className="flex justify-center pt-3 pb-1">
              <div className={`w-10 h-1 rounded-full ${darkMode ? 'bg-gray-700' : 'bg-gray-300'}`} />
            </div>

            {/* History Header */}
            <div className="flex items-center justify-between px-5 py-3">
              <h2 className={`text-xl font-bold ${textPrimary}`}>📋 History</h2>
              <div className="flex gap-2">
                {history.length > 0 && (
                  <button
                    onClick={clearHistory}
                    className={`p-2 rounded-xl ${darkMode ? 'bg-red-500/20 hover:bg-red-500/30' : 'bg-red-50 hover:bg-red-100'} transition-all btn-press`}
                  >
                    <TrashIcon className="w-5 h-5 text-red-400" />
                  </button>
                )}
                <button
                  onClick={() => setShowHistory(false)}
                  className={`p-2 rounded-xl ${darkMode ? 'bg-gray-800 hover:bg-gray-700' : 'bg-gray-100 hover:bg-gray-200'} transition-all btn-press`}
                >
                  <CloseIcon className={`w-5 h-5 ${darkMode ? 'text-gray-400' : 'text-gray-500'}`} />
                </button>
              </div>
            </div>

            {/* History List */}
            <div className="flex-1 overflow-y-auto custom-scroll px-5 pb-8">
              {history.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12">
                  <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-3 ${darkMode ? 'bg-gray-800/50' : 'bg-gray-100'}`}>
                    <span className="text-3xl">📭</span>
                  </div>
                  <p className={`text-sm ${textSecondary}`}>No history yet</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {history.map((item, i) => (
                    <button
                      key={item.id}
                      onClick={() => loadFromHistory(item)}
                      className={`w-full flex items-center gap-3 p-3 rounded-2xl border transition-all btn-press animate-slide-up
                        ${darkMode ? 'bg-gray-800/60 border-gray-700/50 hover:bg-gray-800' : 'bg-gray-50 border-gray-200 hover:bg-gray-100'}
                      `}
                      style={{ animationDelay: `${i * 0.05}s` }}
                    >
                      <div className="shrink-0">
                        <img
                          src={item.preview}
                          alt="History"
                          className="w-12 h-12 rounded-lg"
                          style={{ imageRendering: 'pixelated' }}
                        />
                      </div>
                      <div className="flex-1 text-left min-w-0">
                        <p className={`text-xs font-mono truncate ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>
                          {item.hexCode.substring(0, 50)}...
                        </p>
                        <p className={`text-xs mt-1 ${textSecondary}`}>
                          {new Date(item.timestamp).toLocaleString()}
                        </p>
                      </div>
                      <button
                        onClick={(e) => deleteHistoryItem(item.id, e)}
                        className={`p-2 rounded-lg shrink-0 ${darkMode ? 'hover:bg-red-500/20' : 'hover:bg-red-50'} transition-all`}
                      >
                        <CloseIcon className="w-4 h-4 text-red-400" />
                      </button>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
